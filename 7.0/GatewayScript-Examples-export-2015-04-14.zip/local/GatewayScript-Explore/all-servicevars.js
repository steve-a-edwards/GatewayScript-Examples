// DataPower service-metadata examples.
// This demonstrates various GatewayScript (ECMA) service-metadata information.
// Output also shown in console (system log).
// Author: Steve Edwards, Escala Ltd.
// Date  : 2014-09-30.
// Note  : this code is for demonstration purposes only, not production - level.
// (Based on store:///example-servicevars.js).

var sm = require ('service-metadata');

// Make the MPGW act as a loopback by setting service variables (URL notation):
sm.setVar('var://service/mpgw/skip-backside', true);
// Alternative ...
// Make the MPGW act as a loopback by setting service variables (dotted notation):
// sm.mpgw.skipBackside = true;

// Read the entire list of descriptors of variables using the list() method
var serviceVars = sm.list();

// session.output.write({"smList": serviceVars.length });
// => {"smList":120}

session.output.write({"smList": serviceVars});

var i=0;
var name= '';
for (i = 0; i < serviceVars.length; i++) {
    name = serviceVars[i].name;
    console.log(name + " = " + sm.getVar(name));
}

/* Sample output:
   Outputs entries to logging system, such as:
    mpgw (GatewayScript-Explore-MPGW): var://service/transaction-rule-type = request
    mpgw (GatewayScript-Explore-MPGW): var://service/transaction-id = 117040
    mpgw (GatewayScript-Explore-MPGW): var://service/protocol-method = GET
    mpgw (GatewayScript-Explore-MPGW): var://service/protocol = http
    mpgw (GatewayScript-Explore-MPGW): var://service/transaction-client = 192.168.1.114
   in this format:
{
    "smList": [
        {
            "name": "var://service/aaa-error-logs",
            "writable": false,
            "dataType": "string"
        },
        {
            "name": "var://service/system/ident",
            "writable": false,
            "dataType": "string"
        },
        {
            "name": "var://service/URL-in",
            "writable": false,
            "dataType": "string"
        },
        {
            "name": "var://service/URL-out",
            "writable": false,
            "dataType": "string"
        },
        {
            "name": "var://service/URI",
            "writable": true,
            "dataType": "string"
        },
        {
            "name": "var://service/local-service-address",
            "writable": false,
            "dataType": "string"
        },
        {
            "name": "var://service/client-service-address",
            "writable": false,
            "dataType": "string"
        },
        {
            "name": "var://service/protocol",
            "writable": false,
            "dataType": "string"
        },
        {
            "name": "var://service/protocol-method",
            "writable": true,
            "dataType": "string"
        },
        {
            "name": "var://service/time-started",
            "writable": false,
            "dataType": "number"
        },
        {
            "name": "var://service/time-forwarded",
            "writable": false,
            "dataType": "number"
        },
        {
            "name": "var://service/time-response-complete",
            "writable": false,
            "dataType": "number"
        },
        {
            "name": "var://service/time-elapsed",
            "writable": false,
            "dataType": "number"
        },
        {
            "name": "var://service/memory-used",
            "writable": false,
            "dataType": "number"
        },
        {
            "name": "var://service/error-code",
            "writable": true,
            "dataType": "hexstring"
        },
        {
            "name": "var://service/error-message",
            "writable": true,
            "dataType": "string"
        },
        {
            "name": "var://service/error-protocol-response",
            "writable": true,
            "dataType": "string"
        },
        {
            "name": "var://service/xmlreqrspmode",
            "writable": false,
            "dataType": "string"
        },
        {
            "name": "var://service/error-protocol-reason-phrase",
            "writable": true,
            "dataType": "string"
        },
        {
            "name": "var://service/error-subcode",
            "writable": true,
            "dataType": "hexstring"
        },
        {
            "name": "var://service/error-headers",
            "writable": false,
            "dataType": "string"
        },
        {
            "name": "var://service/formatted-error-message",
            "writable": false,
            "dataType": "string"
        },
        {
            "name": "var://service/error-ignore",
            "writable": true,
            "dataType": "boolean"
        },
        {
            "name": "var://service/strict-error-mode",
            "writable": true,
            "dataType": "boolean"
        },
        {
            "name": "var://service/soap-fault-response",
            "writable": true,
            "dataType": "boolean"
        },
        {
            "name": "var://service/xmlmgr-name",
            "writable": false,
            "dataType": "string"
        },
        {
            "name": "var://service/domain-name",
            "writable": false,
            "dataType": "string"
        },
        {
            "name": "var://service/default-stylesheet",
            "writable": false,
            "dataType": "string"
        },
        {
            "name": "var://service/processor-type",
            "writable": false,
            "dataType": "string"
        },
        {
            "name": "var://service/processor-name",
            "writable": false,
            "dataType": "string"
        },
        {
            "name": "var://service/max-call-depth",
            "writable": true,
            "dataType": "number"
        },
        {
            "name": "var://service/max-action-depth",
            "writable": true,
            "dataType": "number"
        },
        {
            "name": "var://service/system/frontwsdl",
            "writable": false,
            "dataType": "string"
        },
        {
            "name": "var://service/config-param/",
            "writable": true,
            "dataType": "string"
        },
        {
            "name": "var://service/lbhealth/",
            "writable": true,
            "dataType": "string"
        },
        {
            "name": "var://service/lb/group",
            "writable": false,
            "dataType": "string"
        },
        {
            "name": "var://service/lb/member",
            "writable": false,
            "dataType": "string"
        },
        {
            "name": "var://service/transaction-id",
            "writable": false,
            "dataType": "string"
        },
        {
            "name": "var://service/global-transaction-id",
            "writable": false,
            "dataType": "string"
        },
        {
            "name": "var://service/transaction-client",
            "writable": false,
            "dataType": "string"
        },
        {
            "name": "var://service/transaction-rule-name",
            "writable": false,
            "dataType": "string"
        },
        {
            "name": "var://service/transaction-rule-type",
            "writable": false,
            "dataType": "string"
        },
        {
            "name": "var://service/transaction-policy-name",
            "writable": false,
            "dataType": "string"
        },
        {
            "name": "var://service/transaction-audit-trail",
            "writable": false,
            "dataType": "string"
        },
        {
            "name": "var://service/current-call-depth",
            "writable": false,
            "dataType": "number"
        },
        {
            "name": "var://service/input-size",
            "writable": false,
            "dataType": "number"
        },
        {
            "name": "var://service/routing-url",
            "writable": true,
            "dataType": "string"
        },
        {
            "name": "var://service/routing-url-sslprofile",
            "writable": true,
            "dataType": "string"
        },
        {
            "name": "var://service/routing-url-delay-content-type-determination",
            "writable": true,
            "dataType": "string"
        },
        {
            "name": "var://service/persistent-connection-counter",
            "writable": false,
            "dataType": "string"
        },
        {
            "name": "var://service/connection/note",
            "writable": true,
            "dataType": "string"
        },
        {
            "name": "var://service/mpgw/skip-backside",
            "writable": true,
            "dataType": "boolean"
        },
        {
            "name": "var://service/mpgw/backend-timeout",
            "writable": true,
            "dataType": "number"
        },
        {
            "name": "var://service/mpgw/request-size",
            "writable": false,
            "dataType": "number"
        },
        {
            "name": "var://service/mpgw/response-size",
            "writable": false,
            "dataType": "number"
        },
        {
            "name": "var://service/mpgw/proxy-http-response",
            "writable": true,
            "dataType": "string"
        },
        {
            "name": "var://service/http/websocket-upgrade",
            "writable": true,
            "dataType": "boolean"
        },
        {
            "name": "var://service/set-request-header/",
            "writable": true,
            "dataType": "string"
        },
        {
            "name": "var://service/append-request-header/",
            "writable": true,
            "dataType": "string"
        },
        {
            "name": "var://service/set-response-header/",
            "writable": true,
            "dataType": "string"
        },
        {
            "name": "var://service/append-response-header/",
            "writable": true,
            "dataType": "string"
        },
        {
            "name": "var://service/original-content-type",
            "writable": false,
            "dataType": "string"
        },
        {
            "name": "var://service/wsm/enabled",
            "writable": false,
            "dataType": "string"
        },
        {
            "name": "var://service/wsm/wsdl-source-class",
            "writable": false,
            "dataType": "string"
        },
        {
            "name": "var://service/wsm/wsdl-source",
            "writable": false,
            "dataType": "string"
        },
        {
            "name": "var://service/wsm/wsdl",
            "writable": false,
            "dataType": "string"
        },
        {
            "name": "var://service/wsm/service",
            "writable": true,
            "dataType": "string"
        },
        {
            "name": "var://service/wsm/service-port",
            "writable": true,
            "dataType": "string"
        },
        {
            "name": "var://service/wsm/back-service-port",
            "writable": true,
            "dataType": "string"
        },
        {
            "name": "var://service/wsm/binding",
            "writable": false,
            "dataType": "string"
        },
        {
            "name": "var://service/wsm/back-binding",
            "writable": false,
            "dataType": "string"
        },
        {
            "name": "var://service/wsm/binding-data",
            "writable": false,
            "dataType": "string"
        },
        {
            "name": "var://service/wsm/back-binding-data",
            "writable": false,
            "dataType": "string"
        },
        {
            "name": "var://service/wsm/binding-type",
            "writable": false,
            "dataType": "string"
        },
        {
            "name": "var://service/wsm/operation",
            "writable": true,
            "dataType": "string"
        },
        {
            "name": "var://service/wsm/back-operation",
            "writable": true,
            "dataType": "string"
        },
        {
            "name": "var://service/wsm/service-port-operation",
            "writable": false,
            "dataType": "string"
        },
        {
            "name": "var://service/wsm/back-service-port-operation",
            "writable": false,
            "dataType": "string"
        },
        {
            "name": "var://service/wsm/validate-faults",
            "writable": false,
            "dataType": "string"
        },
        {
            "name": "var://service/wsm/validate-headers",
            "writable": false,
            "dataType": "string"
        },
        {
            "name": "var://service/wsm/strict-fault-document-style",
            "writable": false,
            "dataType": "string"
        },
        {
            "name": "var://service/wsm/schemalocation",
            "writable": false,
            "dataType": "string"
        },
        {
            "name": "var://service/wsm/num-subschema",
            "writable": false,
            "dataType": "string"
        },
        {
            "name": "var://service/wsm/validate-message",
            "writable": false,
            "dataType": "string"
        },
        {
            "name": "var://service/wsm/resolve-hrefs",
            "writable": false,
            "dataType": "string"
        },
        {
            "name": "var://service/wsm/aaa-policy-name",
            "writable": false,
            "dataType": "string"
        },
        {
            "name": "var://service/wspolicy/endpoint/configname",
            "writable": false,
            "dataType": "string"
        },
        {
            "name": "var://service/wspolicy/service/configname",
            "writable": false,
            "dataType": "string"
        },
        {
            "name": "var://service/wspolicy/operation/configname",
            "writable": false,
            "dataType": "string"
        },
        {
            "name": "var://service/wspolicy/message/configname",
            "writable": false,
            "dataType": "string"
        },
        {
            "name": "var://service/conformance/policyname",
            "writable": false,
            "dataType": "string"
        },
        {
            "name": "var://service/conformance/generatedPolicy",
            "writable": false,
            "dataType": "string"
        },
        {
            "name": "var://service/wsa/timeout",
            "writable": true,
            "dataType": "number"
        },
        {
            "name": "var://service/wsa/genpattern",
            "writable": true,
            "dataType": "string"
        },
        {
            "name": "var://service/multistep/input-context-name",
            "writable": false,
            "dataType": "string"
        },
        {
            "name": "var://service/multistep/output-context-name",
            "writable": false,
            "dataType": "string"
        },
        {
            "name": "var://service/multistep/loop-iterator",
            "writable": false,
            "dataType": "string"
        },
        {
            "name": "var://service/multistep/loop-count",
            "writable": false,
            "dataType": "number"
        },
        {
            "name": "var://service/multistep/tx-warn",
            "writable": false,
            "dataType": "string"
        },
        {
            "name": "var://service/qos/priority",
            "writable": true,
            "dataType": "string"
        },
        {
            "name": "var://service/wsm/front-protocol",
            "writable": true,
            "dataType": "string"
        },
        {
            "name": "var://service/wsm/back-protocol",
            "writable": true,
            "dataType": "string"
        },
        {
            "name": "var://service/wsm/http-parsed-url-replacement",
            "writable": true,
            "dataType": "string"
        },
        {
            "name": "var://service/wsm/wsdl-content-type",
            "writable": true,
            "dataType": "string"
        },
        {
            "name": "var://service/log/soapversion",
            "writable": true,
            "dataType": "string"
        },
        {
            "name": "var://service/multistep/contexts",
            "writable": false,
            "dataType": "string"
        },
        {
            "name": "var://service/wsm/user-data",
            "writable": true,
            "dataType": "string"
        },
        {
            "name": "var://service/b2b-proxy/message-sign-required",
            "writable": false,
            "dataType": "boolean"
        },
        {
            "name": "var://service/b2b-proxy/message-signature-verified",
            "writable": false,
            "dataType": "boolean"
        },
        {
            "name": "var://service/b2b-proxy/message-encrypt-required",
            "writable": false,
            "dataType": "boolean"
        },
        {
            "name": "var://service/b2b-proxy/message-decrypted",
            "writable": false,
            "dataType": "boolean"
        },
        {
            "name": "var://service/b2b-proxy/is-mdn",
            "writable": false,
            "dataType": "boolean"
        },
        {
            "name": "var://service/b2b-proxy/passthru-enabled",
            "writable": false,
            "dataType": "boolean"
        },
        {
            "name": "var://service/b2b-proxy/integration-id",
            "writable": false,
            "dataType": "string"
        },
        {
            "name": "var://service/b2b-proxy/b2b-partner-from",
            "writable": false,
            "dataType": "string"
        },
        {
            "name": "var://service/b2b-proxy/b2b-partner-to",
            "writable": false,
            "dataType": "string"
        },
        {
            "name": "var://service/b2b-proxy/b2b-message-id",
            "writable": false,
            "dataType": "string"
        },
        {
            "name": "var://service/rewrite-errors",
            "writable": true,
            "dataType": "number"
        },
        {
            "name": "var://service/original-response-content-type",
            "writable": false,
            "dataType": "string"
        },
        {
            "name": "var://service/preserve-mime-encapsulation",
            "writable": true,
            "dataType": "boolean"
        }
    ]
}
*/