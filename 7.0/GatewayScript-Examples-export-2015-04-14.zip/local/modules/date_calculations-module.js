// DataPower user-defined module example: date calculations.
// This demonstrates GatewayScript (ECMA) user-defined module definition.
// Author: Steve Edwards, Escala Ltd.
// Date  : 2015-02-04.
// Note  : this code is for demonstration purposes only, not production - level.

exports.days_to_christmas = function(full_date_string) {
	// full_date_string of form: "2015-02-04"
	var queryDate = new Date(full_date_string);
	var now = new Date();
	var thisYear = now.getFullYear();
	var Xmas = "December 25, " + thisYear;
	var nextXmas = new Date(Xmas);
	// Number of milliseconds per day
	var msPerDay = 24 * 60 * 60 * 1000 ;  
	var daysBetween = (nextXmas.getTime() - queryDate.getTime()) / msPerDay;
	daysBetween = Math.round(daysBetween);
    return daysBetween;
}

