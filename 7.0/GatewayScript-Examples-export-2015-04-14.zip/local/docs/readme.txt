Author	: Steve Edwards, Escala Ltd.
Date	: 2015-02-04.
Purpose	: GatewayScript Examples
Note	: this code is for demonstration purposes only, not production - level.

All code in this domain has been produced by Steve Edwards, Escala Ltd.
and is copyright.
This must NOT be freely distributed.

It is the intention of Escala Ltd. to use this as the basis of a DataPower course.

For more information contact: steve@escala.co.uk


===

This DataPower domain contains various example of the use of GatewayScript.

Other documents in this folder describe the nature of different sets of examples:

GatewayScript-Explore-MPGW.txt
- various basic GatewayScript examples
  - one MPGW service with a variety of rules to trigger different code
  - GatewayScript / JSON access and manipulation
  - accessing service variables
  - accessing local files
  - use of built-in and custom-built modules
  - calls to external systems (url-open)
  - making entries on logs
  - JSON structure validation
  - recursive analysis of complex JSON structures
  
GatewayScript-Explore-Input-Samples.txt
- explains that the corresponding folder contains files that can be used in
  conjunction with the various rules of the GatewayScript-Explore-MPGW service

rest-process-mpgw.txt & daycount-simulator-wsproxy.txt
- a MPGW service that receives a REST-style request
  which is transformed to a SOAP request that is forwarded
  to a Web service, that is emulated in a WS-Proxy
  - URI query parameter processing
  - service variable access
  - transformation of JSON to SOAP
  - use of built-in and custom-built modules
  - transforming SOAP to JSON
- a WS-Proxy service used as a SOAP backend to the MPGW
  - emulates business processing in XSLT
  - can optionally forward on to real backend Web Service
    by re-ordering the rules

Account.txt
- Account Routing System
  - three interacting MPGW services
  - REST-style processing / URI access
  - JSON manipulation
  - accessing processing JSON data files
  - dynamic routing
  - use of stylesheet parameters
  - use of custom-built modules
  - access and manipulation of service variables

 