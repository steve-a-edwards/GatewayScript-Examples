// Accessing incoming JSON and delete item 'overdraft-limit'.
// This demonstrates GatewayScript (ECMA) deleting an item from JSON using its key.
// Author: Steve Edwards, Escala Ltd.
// Date  : 2014-09-30.
// Note  : this code is for demonstration purposes only, not production - level.

// Read the action input as a JSON object
session.input.readAsJSON (function (error, json) {
    if (error) {
      // an error occurred when parsing the content, e.g. invalid JSON object
      // uncatched error will stop the processing and the error will be logged
      throw error;
    }
    delete json["overdraft-limit"];
    session.output.write(json);
});

/* Sample input =>
        {"holder":"Ed Ebony","overdraft-limit":5000,"balance":500}
   Sample output =>
        {"holder":"Ed Ebony","balance":500}
*/