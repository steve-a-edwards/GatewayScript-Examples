// Extract 'from_date' query parameter and constructs SOAP message ready for backend.
// Uses own module for accessing query parameters.
// Author: Steve Edwards, Escala Ltd.
// Date  : 2015-02-04.
// Note  : this code is for demonstration purposes only, not production - level.

var query_parameters_module = require ('modules/query-parameters-module');

// Call function in module
// Sample URL: http://dp-ip:port/query_params-gwscript-to_soap?from_date=2015-01-20
var query_parameters = query_parameters_module.query_parameters();
var from_date = query_parameters.from_date;
console.alert("Request date: " + from_date);
var soap_request = "<S:Envelope xmlns:S=\"http://schemas.xmlsoap.org/soap/envelope/\"><S:Body><ns2:daysToChristmas xmlns:ns2=\"http://service.days/\"><arg0>" + from_date + "</arg0></ns2:daysToChristmas></S:Body></S:Envelope>";
session.output.write(soap_request);