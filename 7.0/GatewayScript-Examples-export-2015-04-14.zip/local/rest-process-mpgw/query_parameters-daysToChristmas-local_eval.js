// Extract 'from_date' query parameter and evaluate daysToChristmas return directly to client.
// Uses own module for accessing query parameters.
// Following action skips backend processing.
// Author: Steve Edwards, Escala Ltd.
// Date  : 2015-02-04.
// Note  : this code is for demonstration purposes only, not production - level.

var query_parameters_module = require ('modules/query-parameters-module');

// Call function in module
// Sample URL: http://dp-ip:port/query_params-gwscript-local_eval?from_date=2015-01-20
var query_parameters = query_parameters_module.query_parameters();
var from_date = query_parameters.from_date;
console.alert("Request from_date: " + from_date);
var queryDate = new Date(from_date);
var now = new Date();
var thisYear = now.getFullYear();
var Xmas = "December 25, " + thisYear;
var nextXmas = new Date(Xmas);
// Number of milliseconds per day
var msPerDay = 24 * 60 * 60 * 1000 ;  
var daysBetween = (nextXmas.getTime() - queryDate.getTime()) / msPerDay;
daysBetween = Math.round(daysBetween);
var jsonOutput = {"daysToChristmas": daysBetween};
session.output.write(jsonOutput);