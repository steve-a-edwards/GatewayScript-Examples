// Getting local file of account-info using stylesheet parameter for its name.
// Author: Steve Edwards, Escala Ltd.
// Date  : 2014-09-30.
// Note  : this code is for demonstration purposes only, not production - level.

var urlopen = require ('urlopen');
var query_parameters_module = require ('modules/query-parameters-module');

// Call function in module
var query_parameters = query_parameters_module.query_parameters();
var account_number = query_parameters.accountNumber;
console.alert("Querying account number: " + account_number);

if (account_number === undefined) {
    var error_msg_json = {"no-account-number-error": "no account number in URI"};
    session.output.write(error_msg_json);
    return;
}

// The stylesheet parameter "account_info_file" is defined in the advanced tab of the script action
var filename = session.parameters.account_info_file;
console.alert("Using account info file: " + filename);

urlopen.open(filename, function (error, response) {
     if (error) {
           session.output.write("openCallback error: " + error.errorMessage+"\n");
     } else {
        if (response.statusCode != 200) {
            // in this case, a non-200 statusCode indicates a problem reading the file
            session.output.write("Unable to open the file, statusCode: " + 
                response.statusCode + ", reasonPhrase: " + 
                response.reasonPhrase);
        } else {
             response.readAsJSON(function(readError, account_info) {
                if (readError) {
                    session.output.write("read file error: " + readError.toString());
                } else {
                    console.alert("Success in reading account info file: " + filename);
                        var selected_account = account_info[account_number];
                        if (selected_account === undefined) {
                            selected_account = {"no-account-numbered-error": account_number};
                        }
                        session.output.write(selected_account);
                }
             });
        }
     }
});
