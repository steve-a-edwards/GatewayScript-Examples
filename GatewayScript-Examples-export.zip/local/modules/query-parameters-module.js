// DataPower user-defined module example: URI query parameters.
// This demonstrates GatewayScript (ECMA) user-defined module definition.
// Author: Steve Edwards, Escala Ltd.
// Date  : 2015-02-04.
// Note  : this code is for demonstration purposes only, not production - level.

exports.query_parameters = function() {

    var sm = require ('service-metadata');

    var client_service_address_JSON = {};

    // Read the service URI as a string
    // result is of form: '/account-info?accountNumber=81&state=CA'
    var uri = sm.getVar ('var://service/URI');

    var qp_json = {};
    // Get the URI string after the '?':
    var qpstring= uri.split("?")[1];
    // if it does exist, then split into parts around the '&'
    // otherwise the initial value for qp_json '{}' is returned:
    
    if (qpstring !== undefined) {
        var qps = qpstring.split("&");
        var key = null;
        var val = null;
        for (var i=0; i<qps.length; i++) {
          key = qps[i].split("=")[0];
          val = qps[i].split("=")[1];
          qp_json[key] = val;
        }
    }
    return qp_json;
}

/* Sample return for above URI:
    {"accountNumber":"81","state":"CA"}
*/
