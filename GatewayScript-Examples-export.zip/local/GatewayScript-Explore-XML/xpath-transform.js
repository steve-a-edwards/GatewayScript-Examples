// XML input converted to JSON output extracting XML components using XPath function.
// This demonstrates GatewayScript (ECMA) XML to JSON.
// Author: Steve Edwards, Escala Ltd.
// Date  : 2015-11-17.
// Note  : this code is for demonstration purposes only, not production - level.
// Read the input as XML document

var transform = require('transform');

session.input.readAsXML(function (error, doc) {
	  if (error) {
	    // handle error
	    session.output.write (error.errorMessage);
	  }
	  else {
		  var options = {
				  'expression': '//ns1:book[1]/ns1:title/text()',
	              'xmldom': doc,
	              'namespace': { 'ns1': 'http://publisher.com/books' }
	      };           
		  transform.xpath(options, function(err, xmlNodeList) {
			  if (err) {
				  session.out.write(err);
			  }
			  else {
				  //  xmlNodeList = 'JavaScript'
				  var json_output = {};
				  var option = { omitXmlDeclaration: true } ;
				  json_output.firstTitle = XML.stringify(option, xmlNodeList);
				  // {"firstTitle": "JavaScript"}
				  session.output.write(json_output);
			  }
		  });
	  }
});
/*
<books xmlns="http://publisher.com/books">
    <book><title>JavaScript</title><price>22.99</price></book>
    <book><title>XSLT</title><price>35</price></book>
</books>

curl -d '<books xmlns="http://publisher.com/books"><book><title>JavaScript</title><price>22.99</price></book><book><title>XSLT</title><price>35</price></book></books>' http://192.168.1.72:8082/xpath-transform
Output: {"firstTitle":"JavaScript"}
*/





