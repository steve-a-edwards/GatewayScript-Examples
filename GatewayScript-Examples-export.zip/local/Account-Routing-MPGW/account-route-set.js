// Getting local file of account route using stylesheet parameter for its name.
// Author: Steve Edwards, Escala Ltd.
// Date  : 2014-09-30.
// Note  : this code is for demonstration purposes only, not production - level.

var sm = require('service-metadata');
var urlopen = require ('urlopen');
var query_parameters_module = require ('modules/query-parameters-module');

// Call function in module
var query_parameters = query_parameters_module.query_parameters();
var customer_state = query_parameters.state;
console.alert("Querying state: " + customer_state);

if (customer_state === undefined) {
    var error_msg_json = {"no-state-name-error": "no state name in URI"};
    session.output.write(error_msg_json);
    return;
}

// The stylesheet parameter "routing_file" is defined in the advanced tab of the script action
var filename = session.parameters.routing_file;
console.alert("Using routing file: " + filename);

urlopen.open(filename, function (error, response) {
     if (error) {
           session.output.write("openCallback error: " + error.errorMessage+"\n");
     } else {
        if (response.statusCode != 200) {
            // in this case, a non-200 statusCode indicates a problem reading the file
            session.output.write("Unable to open the file, statusCode: " + 
                response.statusCode + ", reasonPhrase: " + 
                response.reasonPhrase);
        } else {
             response.readAsJSON(function(readError, state_info) {
                if (readError) {
                    session.output.write("read file error: " + readError.toString());
                } else {
                    console.alert("Success in reading state info file: " + filename);
                    var http_service_route = null;
                    var region_states = null;
                    // following iterates over each object property (east, west, ...)
                    for (var region in state_info) {
                       console.critical(region);
                       region_states = state_info[region].states;
                       // indexOf returns with -1 if not in the array
                       if ((region_states.indexOf(customer_state)) != -1) {
                          http_service_route = state_info[region].http_service_route;
                          console.alert(region);
                          break;
                       };
                    }
                    // Only need to set service variable, no output of interest.
                    // session.output.write({"route": http_service_route});
                    // Propagate incoming URIL
                    var URI = sm.getVar('var://service/URI');
                    var full_route = http_service_route + URI;
                    sm.setVar('var://service/routing-url', full_route) ;
                }
             });
        }
     }
});

