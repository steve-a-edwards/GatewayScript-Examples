// DataPower user-defined module client example
// This demonstrates GatewayScript (ECMA) user-defined module client.
// Author: Steve Edwards, Escala Ltd.
// Date  : 2014-09-30.
// Note  : this code is for demonstration purposes only, not production - level.

var clientIP_module = require ('modules/clientIP-module');

// Determines whether the called function should return only the ip and not the port
// var ip_only = false;
var ip_only = true;

// Call function in module
var client_service_address_JSON = clientIP_module.client_ip_port(ip_only);

session.output.write(client_service_address_JSON);

/* Sample output:
{
    "ip": "192.168.1.112",
    "port": "49318"
}
*/