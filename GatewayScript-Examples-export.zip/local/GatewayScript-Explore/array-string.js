// Input context and array processing examples.
// This demonstrates GatewayScript (ECMA) processing of action input on incoming array structures.
// Author: Steve Edwards, Escala Ltd.
// Date  : 2014-09-30.
// Note  : this code is for demonstration purposes only, not production - level.

session.input.readAsJSON (function (error, json) {
    if (error) {
      // an error occurred when parsing the content, e.g. invalid JSON object
      // uncatched error will stop the processing and the error will be logged
      throw error;
    }

    var processedJSON =
    {
        "reverseArrayResult": json.reverseArray.reverse(),
        "popArrayResult": json.popArray.pop(),
        "sortArrayResult": json.sortArray.sort(),
        "uppercaseStringResult": json.uppercaseString.toUpperCase(),
        // Note the following is a property, NOT a function:
        "lengthStringResult": json.lengthString.length
    };

    session.output.write(processedJSON);

});

/* Sample input into action:
{
    "reverseArray": [
        1, 2, 3, 4
    ],
    "popArray": [
        1, 2, 3, 4
    ],
    "sortArray": [
        1, 4, 3, 2
    ],
    "uppercaseString": "Put all this to UpperCase",
    "lengthString": "12345678"
}
Sample result:
{
    "reverseArrayResult": [
        4,
        3,
        2,
        1
    ],
    "popArrayResult": 4,
    "sortArrayResult": [
        1,
        2,
        3,
        4
    ],
    "uppercaseStringResult": "PUT ALL THIS TO UPPERCASE",
    "lengthStringResult": 8
}
*/

