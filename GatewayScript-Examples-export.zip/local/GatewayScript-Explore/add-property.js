// JSON structure change example / outputting properties.
// This demonstrates GatewayScript (ECMA) adding property and outputting resulting set.
// Author: Steve Edwards, Escala Ltd.
// Date  : 2014-09-30.
// Note  : this code is for demonstration purposes only, not production - level.

// Read the input as a JSON object
session.input.readAsJSON (function (error, json) {
    if (error) {
      // an error occurred when parsing the content, e.g. invalid JSON object
      // uncatched error will stop the processing and the error will be logged
      throw error;
    }
    // Add property to the input object and write to the output context
    json.extra = "Extra value";

    var output = '';
    for (var property in json) {
      output += property + ': ' + json[property]+'; ';
    }
    session.output.write(output);
});

/* Sample intput:

{
    "orig1": 1,
    "orig2": 2
}

   Sample output:
     orig1: 1; orig2: 2; extra: Extra value;

*/