// User-defined recursive function example.
// This demonstrates GatewayScript (ECMA) user-defined function that navigates over
// JSON tree to output object / sub-object information.
// Following function finds type of objects in the JSON structure:
// https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Operators/
// Author: Steve Edwards, Escala Ltd.
// Date  : 2014-09-30.
// Note  : this code is for demonstration purposes only, not production - level.

// parameters:
//    something:      sub-object / primitive type to output
//    string_so_far:  the eventual output string is built up over series of recursive calls
//    to_output_type: boolean that allows for output of sub-object / field type in output
function analyse(something, string_so_far, to_output_type) {
    var building_string = string_so_far;
    var name;
    var something_type = typeof something;
    if ((something_type === "number") || (something_type === "boolean")) {
        building_string = building_string + possibly_output_type(something_type, to_output_type) + something;
    } else {
        if (something_type === "string") {
            building_string = building_string + possibly_output_type(something_type, to_output_type) + "\"" + something + "\"";
        } else {
            // typeof anArray => "object", so need to find out if it is an array:
            if (Array.isArray(something)) {
                building_string = building_string + possibly_output_type("array", to_output_type) + "[";
                var i;
                for (i = 0; i < something.length; i++) {
                    building_string = analyse(something[i], building_string, to_output_type);
                    // Output following comma if not last item in array
                    if (i != (something.length - 1)) building_string = building_string + ", ";
                }
                building_string = building_string + "]";
            } else {
                if (something_type === "object") {
                    // Find number of items in the object
                    var object_size = Object.keys(something).length;
                    var loop_count = 0;
                    building_string = building_string + possibly_output_type(something_type, to_output_type) + "{";
                    // can use for/in only in objects (not arrays)
                    for (name in something) {
                        loop_count += 1;
                        building_string = building_string + " \"" +  name + "\": ";
                        building_string = analyse(something[name], building_string, to_output_type);
                        // Output following comma if not last item in object
                        if (loop_count < object_size) building_string = building_string + ",";
                        // if (something[name] !== last) building_string = building_string + ", ";
                    }
                    building_string = building_string + "}"
                }
                }
        }
    }
    return building_string;
}

// parameters:
//    type_string:    this is the type string of an object determined in the calling recursive function
//    yes_or_no:      boolean that determines if the type of the field is to be output or not
function possibly_output_type(type_string, yes_or_no) {
    var return_value;
    if (yes_or_no) {return_value = "(" + type_string + ") ";} else {return_value = "";};
    return return_value;
}
    
// Read the input as a JSON object
session.input.readAsJSON (function (error, json) {
    if (error) {
      // an error occurred when parsing the content, e.g. invalid JSON object
      // uncatched error will stop the processing and the error will be logged
      throw error;
    }
    // This boolean determines if the type of the objects is output
    var to_output_type = true;
    // This produces a string representation of the JSON,
    // with possible type information (see comment at bottom)
    var output_string = analyse(json, "", to_output_type);

    session.output.write(output_string);

});

/* Sample input:
{
    "account_type": "deposit",
    "balance": 1230,
    "recent-deposits": [
        100,
        130,
        1000,
        {"last": 3},
        2000],
    "is_overdrawn": false
}

   Sample output: with possibly type information in brackets:
(object) {
    "account_type": (string) "deposit",
    "balance": (number) 1230,
    "recent-deposits": (array) [
        (number) 100,
        (number) 130,
        (number) 1000,
        (object) {"last": (number) 3},
        (number) 2000
    ],
    "is_overdrawn": (boolean) false
}
*/

